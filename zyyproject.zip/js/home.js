/**
 * ZYY Cash - Home Module
 * Dashboard and Referral System
 */

import {
    auth,
    db,
    doc,
    getDoc,
    onSnapshot,
    collection,
    query,
    where,
    orderBy,
    limit,
    formatCurrency,
    formatNumber,
    formatDate,
    showToast,
    checkAuth
} from './firebase.js';

// Check authentication
let currentUser = null;
let unsubscribeUser = null;
let unsubscribeActivity = null;

// Initialize page
const init = async () => {
    currentUser = await checkAuth();
    if (!currentUser) return;
    
    loadUserData();
    loadRecentActivity();
    setupEventListeners();
};

// Load user data in real-time
const loadUserData = () => {
    const userRef = doc(db, 'users', currentUser.uid);
    
    unsubscribeUser = onSnapshot(userRef, (docSnap) => {
        if (docSnap.exists()) {
            const data = docSnap.data();
            updateUI(data);
        }
    }, (error) => {
        console.error('Error loading user data:', error);
        showToast('Error', 'Gagal memuat data', 'error');
    });
};

// Update UI with user data
const updateUI = (data) => {
    // Update display name (email prefix)
    const displayName = document.getElementById('displayName');
    if (displayName) {
        const name = data.email ? data.email.split('@')[0] : 'User';
        displayName.textContent = name.charAt(0).toUpperCase() + name.slice(1);
    }
    
    // Update balance
    const balanceAmount = document.getElementById('balanceAmount');
    if (balanceAmount) {
        const saldo = data.saldo || 0;
        balanceAmount.textContent = formatCurrency(saldo).replace('Rp', '').trim();
        balanceAmount.dataset.value = saldo;
    }
    
    // Update stats
    const totalReferral = document.getElementById('totalReferral');
    if (totalReferral) {
        totalReferral.textContent = formatNumber(data.totalReferral || 0);
        animateValue(totalReferral, 0, data.totalReferral || 0, 1000);
    }
    
    const totalWithdraw = document.getElementById('totalWithdraw');
    if (totalWithdraw) {
        totalWithdraw.textContent = formatNumber(data.totalWithdraw || 0);
    }
    
    // Update referral code
    const referralCode = document.getElementById('referralCode');
    if (referralCode) {
        referralCode.textContent = currentUser.uid.substring(0, 8).toUpperCase();
    }
};

// Animate number counting
const animateValue = (element, start, end, duration) => {
    const range = end - start;
    const minTimer = 50;
    let stepTime = Math.abs(Math.floor(duration / range));
    stepTime = Math.max(stepTime, minTimer);
    
    let startTime = new Date().getTime();
    let endTime = startTime + duration;
    let timer;
    
    const run = () => {
        let now = new Date().getTime();
        let remaining = Math.max((endTime - now) / duration, 0);
        let value = Math.round(end - (remaining * range));
        element.textContent = formatNumber(value);
        if (value == end) {
            clearInterval(timer);
        }
    };
    
    timer = setInterval(run, stepTime);
    run();
};

// Load recent activity
const loadRecentActivity = () => {
    const activityQuery = query(
        collection(db, 'withdraw'),
        where('uid', '==', currentUser.uid),
        orderBy('createdAt', 'desc'),
        limit(5)
    );
    
    unsubscribeActivity = onSnapshot(activityQuery, (snapshot) => {
        const activityList = document.getElementById('recentActivity');
        if (!activityList) return;
        
        if (snapshot.empty) {
            activityList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-inbox"></i>
                    </div>
                    <p>Belum ada aktivitas</p>
                </div>
            `;
            return;
        }
        
        let html = '';
        snapshot.forEach((doc) => {
            const data = doc.data();
            const date = formatDate(data.createdAt);
            const statusClass = data.status === 'SUCCESS' ? 'success' : 'pending';
            const statusIcon = data.status === 'SUCCESS' ? 'check' : 'clock';
            const methodIcon = getMethodIcon(data.method);
            
            html += `
                <div class="activity-item glass-card-small" style="padding: 12px; margin-bottom: 8px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div style="width: 40px; height: 40px; border-radius: 10px; background: ${getMethodColor(data.method)}; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="${methodIcon}"></i>
                            </div>
                            <div>
                                <div style="font-weight: 600; font-size: 14px;">Withdraw ${data.method}</div>
                                <div style="font-size: 12px; color: var(--text-tertiary);">${date}</div>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-weight: 700; font-family: var(--font-mono);">${formatCurrency(data.amount)}</div>
                            <span class="status-badge ${statusClass.toLowerCase()}">
                                <i class="fas fa-${statusIcon}"></i> ${data.status}
                            </span>
                        </div>
                    </div>
                </div>
            `;
        });
        
        activityList.innerHTML = html;
    });
};

const getMethodIcon = (method) => {
    const icons = {
        'DANA': 'fas fa-wallet',
        'SHOPEE': 'fas fa-shopping-bag',
        'BANK': 'fas fa-university'
    };
    return icons[method] || 'fas fa-money-bill';
};

const getMethodColor = (method) => {
    const colors = {
        'DANA': 'linear-gradient(135deg, #0081FF 0%, #0056B3 100%)',
        'SHOPEE': 'linear-gradient(135deg, #EE4D2D 0%, #D0401B 100%)',
        'BANK': 'linear-gradient(135deg, #34C759 0%, #248A3D 100%)'
    };
    return colors[method] || '#666';
};

// Event Listeners
const setupEventListeners = () => {
    // Toggle balance visibility
    window.toggleBalance = () => {
        const amount = document.getElementById('balanceAmount');
        const icon = document.getElementById('eyeIcon');
        
        if (amount.dataset.hidden === 'true') {
            const value = amount.dataset.value || 0;
            amount.textContent = formatCurrency(parseInt(value)).replace('Rp', '').trim();
            amount.dataset.hidden = 'false';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        } else {
            amount.textContent = '••••••';
            amount.dataset.hidden = 'true';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        }
    };
    
    // Copy referral code
    window.copyReferralCode = () => {
        const code = document.getElementById('referralCode').textContent;
        navigator.clipboard.writeText(code).then(() => {
            const feedback = document.getElementById('copyFeedback');
            if (feedback) {
                feedback.classList.add('show');
                setTimeout(() => feedback.classList.remove('show'), 2000);
            }
            showToast('Sukses', 'Kode referral disalin!', 'success');
        }).catch(() => {
            showToast('Error', 'Gagal menyalin kode', 'error');
        });
    };
    
    // Share functions
    window.shareToWhatsApp = () => {
        const code = document.getElementById('referralCode').textContent;
        const text = `Gabung ZYY Cash dan dapatkan bonus! Gunakan kode referral saya: ${code}\n\nDaftar di: ${window.location.origin}`;
        window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
    };
    
    window.shareToTelegram = () => {
        const code = document.getElementById('referralCode').textContent;
        const text = `Gabung ZYY Cash dan dapatkan bonus! Gunakan kode referral saya: ${code}`;
        window.open(`https://t.me/share/url?url=${encodeURIComponent(window.location.origin)}&text=${encodeURIComponent(text)}`, '_blank');
    };
    
    window.shareMore = () => {
        const code = document.getElementById('referralCode').textContent;
        const text = `Gabung ZYY Cash dan dapatkan bonus! Gunakan kode referral saya: ${code}`;
        
        if (navigator.share) {
            navigator.share({
                title: 'ZYY Cash - Referral',
                text: text,
                url: window.location.origin
            }).catch(() => {
                copyReferralCode();
            });
        } else {
            copyReferralCode();
        }
    };
    
    window.showReferralDetails = () => {
        showToast('Info', 'Total referral yang berhasil bergabung', 'info');
    };
    
    window.showNotifications = () => {
        showToast('Info', 'Tidak ada notifikasi baru', 'info');
    };
};

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (unsubscribeUser) unsubscribeUser();
    if (unsubscribeActivity) unsubscribeActivity();
});

// Initialize
document.addEventListener('DOMContentLoaded', init);
