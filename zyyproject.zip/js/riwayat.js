/**
 * ZYY Cash - Riwayat Module
 * Withdrawal History
 */

import {
    auth,
    db,
    collection,
    query,
    where,
    orderBy,
    onSnapshot,
    formatCurrency,
    formatDateTime,
    showToast,
    checkAuth
} from './firebase.js';

// Check authentication
let currentUser = null;
let unsubscribeHistory = null;
let currentFilter = 'all';

// Initialize
const init = async () => {
    currentUser = await checkAuth();
    if (!currentUser) return;
    
    loadHistory();
    setupEventListeners();
};

// Load history with real-time updates
const loadHistory = () => {
    const historyList = document.getElementById('historyList');
    const emptyState = document.getElementById('emptyState');
    
    // Build query based on filter
    let historyQuery = query(
        collection(db, 'withdraw'),
        where('uid', '==', currentUser.uid),
        orderBy('createdAt', 'desc')
    );
    
    if (unsubscribeHistory) unsubscribeHistory();
    
    unsubscribeHistory = onSnapshot(historyQuery, (snapshot) => {
        // Update stats
        updateStats(snapshot.docs);
        
        // Filter docs
        let docs = snapshot.docs;
        if (currentFilter !== 'all') {
            docs = docs.filter(doc => doc.data().status === currentFilter);
        }
        
        if (docs.length === 0) {
            historyList.innerHTML = '';
            emptyState.classList.remove('hidden');
            return;
        }
        
        emptyState.classList.add('hidden');
        
        let html = '';
        docs.forEach((doc) => {
            const data = doc.data();
            const dateTime = formatDateTime(data.createdAt);
            
            html += createHistoryItem(doc.id, data, dateTime);
        });
        
        historyList.innerHTML = html;
        
        // Add click handlers
        docs.forEach((doc) => {
            const element = document.getElementById(`history-${doc.id}`);
            if (element) {
                element.addEventListener('click', () => showDetail(doc.id, doc.data()));
            }
        });
    }, (error) => {
        console.error('Error loading history:', error);
        showToast('Error', 'Gagal memuat riwayat', 'error');
    });
};

// Create history item HTML
const createHistoryItem = (id, data, dateTime) => {
    const statusClass = data.status === 'SUCCESS' ? 'success' : 'pending';
    const statusIcon = data.status === 'SUCCESS' ? 'check' : 'clock';
    const methodIcon = getMethodIcon(data.method);
    const methodColor = getMethodColor(data.method);
    
    return `
        <div class="history-item glass-card" id="history-${id}">
            <div class="history-main">
                <div class="history-method">
                    <div class="method-badge ${data.method.toLowerCase()}" style="background: ${methodColor};">
                        <i class="${methodIcon}"></i>
                    </div>
                    <div class="method-info">
                        <span class="method-name">Withdraw ${data.method}</span>
                        <span class="method-number">${maskNumber(data.accountNumber)}</span>
                    </div>
                </div>
                <div class="history-amount">
                    <span class="amount-text">${formatCurrency(data.amount)}</span>
                </div>
            </div>
            <div class="history-meta">
                <span class="history-date">${dateTime.date}</span>
                <span class="status-badge ${statusClass.toLowerCase()}">
                    <i class="fas fa-${statusIcon}"></i> ${data.status}
                </span>
            </div>
        </div>
    `;
};

const getMethodIcon = (method) => {
    const icons = {
        'DANA': 'fas fa-wallet',
        'SHOPEE': 'fas fa-shopping-bag',
        'BANK': 'fas fa-university'
    };
    return icons[method] || 'fas fa-money-bill';
};

const getMethodColor = (method) => {
    const colors = {
        'DANA': 'linear-gradient(135deg, #0081FF 0%, #0056B3 100%)',
        'SHOPEE': 'linear-gradient(135deg, #EE4D2D 0%, #D0401B 100%)',
        'BANK': 'linear-gradient(135deg, #34C759 0%, #248A3D 100%)'
    };
    return colors[method] || '#666';
};

const maskNumber = (number) => {
    if (!number) return '-';
    const str = number.toString();
    if (str.length < 4) return str;
    return str.substring(0, 2) + '••••' + str.substring(str.length - 2);
};

// Update statistics
const updateStats = (docs) => {
    const totalEl = document.getElementById('totalTransactions');
    const successEl = document.getElementById('totalSuccess');
    const amountEl = document.getElementById('totalAmount');
    
    const total = docs.length;
    const success = docs.filter(d => d.data().status === 'SUCCESS').length;
    const totalAmount = docs
        .filter(d => d.data().status === 'SUCCESS')
        .reduce((sum, d) => sum + (d.data().amount || 0), 0);
    
    if (totalEl) totalEl.textContent = total;
    if (successEl) successEl.textContent = success;
    if (amountEl) amountEl.textContent = formatCurrency(totalAmount);
};

// Setup event listeners
const setupEventListeners = () => {
    // Filter tabs
    const filterTabs = document.querySelectorAll('.filter-tab');
    filterTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            filterTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            currentFilter = tab.dataset.filter;
            loadHistory();
        });
    });
};

// Show detail modal
window.showDetail = (id, data) => {
    const modal = document.getElementById('detailModal');
    const dateTime = formatDateTime(data.createdAt);
    
    // Update status badge
    const statusBadge = document.getElementById('detailStatus');
    statusBadge.className = `status-badge-large ${data.status.toLowerCase()}`;
    statusBadge.innerHTML = `
        <i class="fas fa-${data.status === 'SUCCESS' ? 'check-circle' : 'clock'}"></i>
        <span>${data.status}</span>
    `;
    
    // Update details
    document.getElementById('detailAmount').textContent = formatCurrency(data.amount);
    document.getElementById('detailId').textContent = id.substring(0, 12) + '...';
    document.getElementById('detailMethod').textContent = data.method === 'BANK' ? 
        `${data.method} ${data.bankName || ''}` : data.method;
    document.getElementById('detailNumber').textContent = data.accountNumber;
    document.getElementById('detailName').textContent = data.accountName;
    document.getElementById('detailDate').textContent = dateTime.date;
    document.getElementById('detailTime').textContent = dateTime.time;
    
    modal.classList.remove('hidden');
};

window.closeDetailModal = () => {
    const modal = document.getElementById('detailModal');
    modal.classList.add('hidden');
};

// Cleanup
window.addEventListener('beforeunload', () => {
    if (unsubscribeHistory) unsubscribeHistory();
});

// Initialize
document.addEventListener('DOMContentLoaded', init);
