/**
 * CUPZ History Module
 * Handles transaction history and filtering
 */

import { auth, db } from './firebase-config.js';
import { onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js';
import {
    collection,
    query,
    where,
    orderBy,
    getDocs,
    limit,
    startAfter
} from 'https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js';

let currentUser = null;
let allHistory = [];
let lastDoc = null;
let currentFilter = 'all';

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    onAuthStateChanged(auth, async (user) => {
        if (user) {
            currentUser = user;
            await loadHistory();
        }
    });
});

// Load History
const loadHistory = async () => {
    window.showLoading('Memuat riwayat...');
    
    try {
        let historyQuery = query(
            collection(db, 'withdrawals'),
            where('userId', '==', currentUser.uid),
            orderBy('createdAt', 'desc'),
            limit(50)
        );

        const snapshot = await getDocs(historyQuery);
        allHistory = [];
        let totalAmount = 0;
        let totalCount = 0;

        snapshot.forEach(doc => {
            const data = doc.data();
            allHistory.push({
                id: doc.id,
                ...data,
                createdAt: data.createdAt?.toDate() || new Date(),
                processedAt: data.processedAt?.toDate() || null
            });
            
            if (data.status === 'success') {
                totalAmount += data.amount;
                totalCount++;
            }
        });

        if (window.updateHistory) {
            window.updateHistory(allHistory, {
                total: totalAmount,
                count: totalCount
            });
        }

        window.hideLoading();
    } catch (error) {
        console.error('Load history error:', error);
        window.hideLoading();
        window.showToast('Error', 'Gagal memuat riwayat', 'error');
    }
};

// Apply Filter
window.applyHistoryFilter = async () => {
    const dateFrom = document.getElementById('dateFrom').value;
    const dateTo = document.getElementById('dateTo').value;
    const methods = Array.from(document.querySelectorAll('.filter-chip input:checked')).map(cb => cb.value);
    const statuses = Array.from(document.querySelectorAll('.filter-section:last-child .filter-chip input:checked')).map(cb => cb.value);

    window.showLoading('Menerapkan filter...');

    try {
        let filtered = allHistory;

        // Filter by date
        if (dateFrom) {
            const fromDate = new Date(dateFrom);
            filtered = filtered.filter(item => item.createdAt >= fromDate);
        }
        
        if (dateTo) {
            const toDate = new Date(dateTo);
            toDate.setHours(23, 59, 59);
            filtered = filtered.filter(item => item.createdAt <= toDate);
        }

        // Filter by method
        filtered = filtered.filter(item => methods.includes(item.method));

        // Filter by status
        filtered = filtered.filter(item => statuses.includes(item.status));

        // Update UI
        const totalAmount = filtered
            .filter(item => item.status === 'success')
            .reduce((sum, item) => sum + item.amount, 0);

        if (window.updateHistory) {
            window.updateHistory(filtered, {
                total: totalAmount,
                count: filtered.length
            });
        }

        window.hideLoading();
    } catch (error) {
        console.error('Filter error:', error);
        window.hideLoading();
    }
};
