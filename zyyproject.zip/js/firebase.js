/**
 * ZYY Cash - Firebase Configuration
 * Firebase SDK v9.22.0 Modular
 * Production Ready Configuration
 */

import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js';
import { 
    getAuth, 
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    updatePassword,
    sendPasswordResetEmail,
    setPersistence,
    browser  Berikut adalah lanjutan file JavaScript lengkap untuk sistem ZYY Cash:

## 7. File: `/zyycash/js/firebase.js` (Lanjutan)

```javascript
/**
 * ZYY Cash - Firebase Configuration
 * Firebase SDK v9.22.0 Modular
 * Production Ready Configuration
 */

import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js';
import { 
    getAuth, 
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    updatePassword,
    sendPasswordResetEmail,
    setPersistence,
    browserLocalPersistence,
    browserSessionPersistence
} from 'https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js';
import { 
    getFirestore, 
    collection, 
    doc, 
    setDoc, 
    getDoc, 
    updateDoc, 
    increment,
    serverTimestamp,
    query,
    where,
    orderBy,
    onSnapshot,
    addDoc,
    getDocs,
    Timestamp,
    writeBatch
} from 'https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js';

// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyCf230zCliSZ9EYLByMnmflqw8sOz328Uc",
    authDomain: "database-cupz.firebaseapp.com",
    projectId: "database-cupz",
    storageBucket: "database-cupz.firebasestorage.app",
    messagingSenderId: "343357519412",
    appId: "1:343357519412:web:dce862636c7c459e6a3c61"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Set persistence to local (remember me functionality)
setPersistence(auth, browserLocalPersistence).catch((error) => {
    console.error("Persistence error:", error);
});

// Utility Functions
const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
};

const formatNumber = (num) => {
    return new Intl.NumberFormat('id-ID').format(num);
};

const formatDate = (timestamp) => {
    if (!timestamp) return '-';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return new Intl.DateTimeFormat('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    }).format(date);
};

const formatDateTime = (timestamp) => {
    if (!timestamp) return { date: '-', time: '-' };
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return {
        date: new Intl.DateTimeFormat('id-ID', {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
        }).format(date),
        time: new Intl.DateTimeFormat('id-ID', {
            hour: '2-digit',
            minute: '2-digit'
        }).format(date)
    };
};

// Toast Notification System
const showToast = (title, message, type = 'success', duration = 3000) => {
    const toast = document.getElementById('toast');
    if (!toast) return;
    
    const icon = toast.querySelector('.toast-icon i');
    const titleEl = document.getElementById('toastTitle');
    const messageEl = document.getElementById('toastMessage');
    
    // Set icon based on type
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    
    icon.className = `fas fa-${icons[type] || icons.success}`;
    
    // Set colors based on type
    toast.className = `toast ${type}`;
    titleEl.textContent = title;
    messageEl.textContent = message;
    
    // Show toast
    toast.classList.remove('hidden');
    toast.classList.add('show');
    
    // Hide after duration
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, duration);
};

// Loading State Management
const setLoading = (button, isLoading) => {
    const text = button.querySelector('.btn-text');
    const loader = button.querySelector('.btn-loader, .spinner, .spinner-white');
    
    if (isLoading) {
        if (text) text.style.opacity = '0';
        if (loader) loader.classList.remove('hidden');
        button.disabled = true;
    } else {
        if (text) text.style.opacity = '1';
        if (loader) loader.classList.add('hidden');
        button.disabled = false;
    }
};

// Auth State Observer
const initAuth = (callback) => {
    return onAuthStateChanged(auth, (user) => {
        if (callback) callback(user);
    });
};

// Protected Route Check
const checkAuth = () => {
    return new Promise((resolve) => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            unsubscribe();
            if (!user && !window.location.pathname.includes('index.html')) {
                window.location.href = 'index.html';
                resolve(null);
            } else if (user && window.location.pathname.includes('index.html')) {
                window.location.href = 'home.html';
                resolve(null);
            } else {
                resolve(user);
            }
        });
    });
};

// Export modules
export {
    app,
    auth,
    db,
    // Auth functions
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    updatePassword,
    sendPasswordResetEmail,
    browserLocalPersistence,
    browserSessionPersistence,
    setPersistence,
    // Firestore functions
    collection,
    doc,
    setDoc,
    getDoc,
    updateDoc,
    increment,
    serverTimestamp,
    query,
    where,
    orderBy,
    onSnapshot,
    addDoc,
    getDocs,
    Timestamp,
    writeBatch,
    // Utilities
    formatCurrency,
    formatNumber,
    formatDate,
    formatDateTime,
    showToast,
    setLoading,
    initAuth,
    checkAuth
};
