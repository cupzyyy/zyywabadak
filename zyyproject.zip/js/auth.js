/**
 * ZYY Cash - Authentication Module
 * Handles Login, Register, and Password Reset
 */

import {
    auth,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    sendPasswordResetEmail,
    db,
    doc,
    setDoc,
    serverTimestamp,
    setPersistence,
    browserLocalPersistence,
    browserSessionPersistence,
    showToast,
    setLoading,
    checkAuth
} from './firebase.js';

// Check auth state on load
checkAuth();

// DOM Elements
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const forgotForm = document.getElementById('forgotForm');

// Switch between auth modes
window.switchAuthMode = (mode) => {
    const forms = {
        login: loginForm,
        register: registerForm,
        forgot: forgotForm
    };
    
    // Hide all forms
    Object.values(forms).forEach(form => {
        if (form) {
            form.classList.add('hidden');
            form.classList.remove('active');
        }
    });
    
    // Show selected form
    if (forms[mode]) {
        forms[mode].classList.remove('hidden');
        forms[mode].classList.add('active');
        
        // Animation
        forms[mode].style.opacity = '0';
        forms[mode].style.transform = 'translateY(10px)';
        setTimeout(() => {
            forms[mode].style.transition = 'all 0.3s ease';
            forms[mode].style.opacity = '1';
            forms[mode].style.transform = 'translateY(0)';
        }, 10);
    }
};

window.showForgotPassword = () => switchAuthMode('forgot');

// Toggle password visibility
window.togglePassword = (inputId) => {
    const input = document.getElementById(inputId);
    const button = input.nextElementSibling || input.parentElement.querySelector('.toggle-password, .toggle-password-inline');
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
};

// Handle Login
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('loginEmail').value.trim();
        const password = document.getElementById('loginPassword').value;
        const rememberMe = document.getElementById('rememberMe').checked;
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        
        if (!email || !password) {
            showToast('Error', 'Email dan password wajib diisi', 'error');
            return;
        }
        
        setLoading(submitBtn, true);
        
        try {
            // Set persistence based on remember me
            await setPersistence(auth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
            
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;
            
            showToast('Sukses', 'Login berhasil! Mengalihkan...', 'success');
            
            setTimeout(() => {
                window.location.href = 'home.html';
            }, 1000);
            
        } catch (error) {
            console.error('Login error:', error);
            let errorMessage = 'Terjadi kesalahan saat login';
            
            switch (error.code) {
                case 'auth/user-not-found':
                    errorMessage = 'Email tidak terdaftar';
                    break;
                case 'auth/wrong-password':
                    errorMessage = 'Password salah';
                    break;
                case 'auth/invalid-email':
                    errorMessage = 'Format email tidak valid';
                    break;
                case 'auth/user-disabled':
                    errorMessage = 'Akun ini telah dinonaktifkan';
                    break;
                case 'auth/too-many-requests':
                    errorMessage = 'Terlalu banyak percobaan. Coba lagi nanti';
                    break;
            }
            
            showToast('Login Gagal', errorMessage, 'error');
        } finally {
            setLoading(submitBtn, false);
        }
    });
}

// Handle Register
if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('registerEmail').value.trim();
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const agreeTerms = document.getElementById('agreeTerms').checked;
        const submitBtn = registerForm.querySelector('button[type="submit"]');
        
        // Validation
        if (!email || !password || !confirmPassword) {
            showToast('Error', 'Semua field wajib diisi', 'error');
            return;
        }
        
        if (password.length < 6) {
            showToast('Error', 'Password minimal 6 karakter', 'error');
            return;
        }
        
        if (password !== confirmPassword) {
            showToast('Error', 'Password tidak cocok', 'error');
            return;
        }
        
        if (!agreeTerms) {
            showToast('Error', 'Anda harus menyetujui syarat dan ketentuan', 'error');
            return;
        }
        
        setLoading(submitBtn, true);
        
        try {
            // Create user
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;
            
            // Create user document in Firestore
            await setDoc(doc(db, 'users', user.uid), {
                email: email,
                saldo: 0,
                totalReferral: 0,
                totalWithdraw: 0,
                joinDate: serverTimestamp(),
                lastLogin: serverTimestamp(),
                status: 'active'
            });
            
            showToast('Sukses', 'Akun berhasil dibuat! Mengalihkan...', 'success');
            
            setTimeout(() => {
                window.location.href = 'home.html';
            }, 1500);
            
        } catch (error) {
            console.error('Register error:', error);
            let errorMessage = 'Terjadi kesalahan saat mendaftar';
            
            switch (error.code) {
                case 'auth/email-already-in-use':
                    errorMessage = 'Email sudah terdaftar';
                    break;
                case 'auth/invalid-email':
                    errorMessage = 'Format email tidak valid';
                    break;
                case 'auth/weak-password':
                    errorMessage = 'Password terlalu lemah';
                    break;
                case 'auth/operation-not-allowed':
                    errorMessage = 'Pendaftaran tidak diizinkan';
                    break;
            }
            
            showToast('Pendaftaran Gagal', errorMessage, 'error');
        } finally {
            setLoading(submitBtn, false);
        }
    });
}

// Handle Forgot Password
if (forgotForm) {
    forgotForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('resetEmail').value.trim();
        const submitBtn = forgotForm.querySelector('button[type="submit"]');
        
        if (!email) {
            showToast('Error', 'Masukkan email Anda', 'error');
            return;
        }
        
        setLoading(submitBtn, true);
        
        try {
            await sendPasswordResetEmail(auth, email);
            showToast('Sukses', 'Link reset password telah dikirim ke email Anda', 'success');
            
            setTimeout(() => {
                switchAuthMode('login');
            }, 2000);
            
        } catch (error) {
            console.error('Reset error:', error);
            let errorMessage = 'Terjadi kesalahan';
            
            switch (error.code) {
                case 'auth/user-not-found':
                    errorMessage = 'Email tidak terdaftar';
                    break;
                case 'auth/invalid-email':
                    errorMessage = 'Format email tidak valid';
                    break;
                case 'auth/too-many-requests':
                    errorMessage = 'Terlalu banyak permintaan. Coba lagi nanti';
                    break;
            }
            
            showToast('Error', errorMessage, 'error');
        } finally {
            setLoading(submitBtn, false);
        }
    });
}

// Check if user is already logged in (auto redirect)
const unsubscribe = auth.onAuthStateChanged((user) => {
    if (user && window.location.pathname.includes('index.html')) {
        window.location.href = 'home.html';
    }
    unsubscribe();
});
