/**
 * ZYY Cash - Profile Module
 * User Profile Management
 */

import {
    auth,
    db,
    doc,
    getDoc,
    updatePassword,
    signOut,
    formatCurrency,
    formatDate,
    formatNumber,
    showToast,
    setLoading,
    checkAuth
} from './firebase.js';

// Check authentication
let currentUser = null;
let userData = null;

// Initialize
const init = async () => {
    currentUser = await checkAuth();
    if (!currentUser) return;
    
    loadUserData();
    setupEventListeners();
};

// Load user data
const loadUserData = async () => {
    try {
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        
        if (userSnap.exists()) {
            userData = userSnap.data();
            updateUI(userData);
        }
    } catch (error) {
        console.error('Error loading profile:', error);
        showToast('Error', 'Gagal memuat data profil', 'error');
    }
};

// Update UI
const updateUI = (data) => {
    // Email
    const emailEl = document.getElementById('userEmail');
    if (emailEl) emailEl.textContent = data.email || currentUser.email;
    
    // UID
    const uidEl = document.getElementById('userUid');
    if (uidEl) uidEl.textContent = `UID: ${currentUser.uid.substring(0, 16)}...`;
    
    // Join date
    const joinDateEl = document.getElementById('joinDate');
    if (joinDateEl) {
        joinDateEl.textContent = data.joinDate ? 
            formatDate(data.joinDate) : '-';
    }
    
    // Current balance
    const balanceEl = document.getElementById('currentBalance');
    if (balanceEl) {
        balanceEl.textContent = formatCurrency(data.saldo || 0);
    }
    
    // Referral count
    const referralEl = document.getElementById('profileReferral');
    if (referralEl) {
        referralEl.textContent = formatNumber(data.totalReferral || 0);
    }
    
    // Total withdraw
    const withdrawEl = document.getElementById('profileWithdraw');
    if (withdrawEl) {
        withdrawEl.textContent = formatCurrency(data.totalWithdraw || 0);
    }
};

// Setup event listeners
const setupEventListeners = () => {
    // Change password form
    const passwordForm = document.getElementById('changePasswordForm');
    if (passwordForm) {
        passwordForm.addEventListener('submit', handleChangePassword);
    }
};

// Handle change password
const handleChangePassword = async (e) => {
    e.preventDefault();
    
    const currentPass = document.getElementById('currentPassword').value;
    const newPass = document.getElementById('newPassword').value;
    const confirmPass = document.getElementById('confirmNewPassword').value;
    const submitBtn = e.target.querySelector('button[type="submit"]');
    
    if (!currentPass || !newPass || !confirmPass) {
        showToast('Error', 'Semua field wajib diisi', 'error');
        return;
    }
    
    if (newPass.length < 6) {
        showToast('Error', 'Password baru minimal 6 karakter', 'error');
        return;
    }
    
    if (newPass !== confirmPass) {
        showToast('Error', 'Password baru tidak cocok', 'error');
        return;
    }
    
    setLoading(submitBtn, true);
    
    try {
        await updatePassword(currentUser, newPass);
        showToast('Sukses', 'Password berhasil diubah!', 'success');
        closePasswordModal();
        e.target.reset();
    } catch (error) {
        console.error('Change password error:', error);
        let errorMessage = 'Gagal mengubah password';
        
        if (error.code === 'auth/requires-recent-login') {
            errorMessage = 'Silakan login ulang untuk mengubah password';
        } else if (error.code === 'auth/weak-password') {
            errorMessage = 'Password terlalu lemah';
        }
        
        showToast('Error', errorMessage, 'error');
    } finally {
        setLoading(submitBtn, false);
    }
};

// Modal functions
window.showChangePassword = () => {
    const modal = document.getElementById('passwordModal');
    modal.classList.remove('hidden');
};

window.closePasswordModal = () => {
    const modal = document.getElementById('passwordModal');
    modal.classList.add('hidden');
};

// Other menu functions
window.showEditProfile = () => {
    showToast('Info', 'Fitur edit profil segera hadir', 'info');
};

window.showSecurityLog = () => {
    showToast('Info', 'Tidak ada aktivitas mencurigakan', 'success');
};

window.showVerification = () => {
    showToast('Info', 'Akun Anda sudah terverifikasi', 'success');
};

window.showHelp = () => {
    showToast('Info', 'Hubungi support@zyycash.com', 'info');
};

window.showContact = () => {
    showToast('Info', 'Email: support@zyycash.com', 'info');
};

window.showSettings = () => {
    showToast('Info', 'Pengaturan sistem', 'info');
};

// Logout
window.handleLogout = async () => {
    if (!confirm('Apakah Anda yakin ingin keluar?')) return;
    
    try {
        await signOut(auth);
        showToast('Sukses', 'Berhasil keluar', 'success');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
    } catch (error) {
        console.error('Logout error:', error);
        showToast('Error', 'Gagal keluar', 'error');
    }
};

// Toggle password in modal
window.togglePassword = (inputId) => {
    const input = document.getElementById(inputId);
    const button = input.parentElement.querySelector('.toggle-password-inline');
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', init);
