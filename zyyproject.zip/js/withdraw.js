/**
 * ZYY Cash - Withdraw Module
 * Withdrawal Request System
 */

import {
    auth,
    db,
    doc,
    getDoc,
    addDoc,
    collection,
    serverTimestamp,
    formatCurrency,
    showToast,
    setLoading,
    checkAuth
} from './firebase.js';

// Check authentication
let currentUser = null;
let userData = null;
let withdrawAmount = 0;

// Initialize
const init = async () => {
    currentUser = await checkAuth();
    if (!currentUser) return;
    
    await loadUserData();
    setupEventListeners();
    setupPaymentMethodLogic();
};

// Load user data
const loadUserData = async () => {
    try {
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        
        if (userSnap.exists()) {
            userData = userSnap.data();
            const balanceEl = document.getElementById('availableBalance');
            if (balanceEl) {
                balanceEl.textContent = formatCurrency(userData.saldo || 0);
                balanceEl.dataset.saldo = userData.saldo || 0;
            }
        }
    } catch (error) {
        console.error('Error loading user data:', error);
        showToast('Error', 'Gagal memuat data saldo', 'error');
    }
};

// Setup payment method logic
const setupPaymentMethodLogic = () => {
    const methodCards = document.querySelectorAll('.method-card');
    const accountNumberGroup = document.getElementById('accountNumberGroup');
    const accountNumberLabel = document.getElementById('accountNumberLabel');
    const accountNumberInput = document.getElementById('accountNumber');
    const bankGroup = document.getElementById('bankGroup');
    
    methodCards.forEach(card => {
        card.addEventListener('click', () => {
            const method = card.dataset.method;
            
            // Update UI based on method
            if (method === 'BANK') {
                accountNumberLabel.textContent = 'Nomor Rekening';
                accountNumberInput.placeholder = 'Contoh: 1234567890';
                bankGroup.classList.remove('hidden');
            } else {
                accountNumberLabel.textContent = 'Nomor E-Wallet';
                accountNumberInput.placeholder = 'Contoh: 08123456789';
                bankGroup.classList.add('hidden');
            }
        });
    });
};

// Setup event listeners
const setupEventListeners = () => {
    // Quick amount buttons
    window.setAmount = (amount) => {
        const input = document.getElementById('withdrawAmount');
        input.value = amount;
        input.focus();
    };
    
    window.setMaxAmount = () => {
        const saldo = parseInt(document.getElementById('availableBalance').dataset.saldo || 0);
        const input = document.getElementById('withdrawAmount');
        input.value = saldo;
        input.focus();
    };
    
    // Form submission
    const form = document.getElementById('withdrawForm');
    if (form) {
        form.addEventListener('submit', handleWithdrawSubmit);
    }
};

// Handle withdraw submit
const handleWithdrawSubmit = async (e) => {
    e.preventDefault();
    
    // Get form data
    const method = document.querySelector('input[name="paymentMethod"]:checked')?.value;
    const accountNumber = document.getElementById('accountNumber').value.trim();
    const bankName = document.getElementById('bankName')?.value;
    const accountName = document.getElementById('accountName').value.trim();
    const amount = parseInt(document.getElementById('withdrawAmount').value);
    
    // Validation
    if (!method) {
        showToast('Error', 'Pilih metode pembayaran', 'error');
        return;
    }
    
    if (!accountNumber) {
        showToast('Error', 'Masukkan nomor rekening/e-wallet', 'error');
        return;
    }
    
    if (method === 'BANK' && !bankName) {
        showToast('Error', 'Pilih bank tujuan', 'error');
        return;
    }
    
    if (!accountName) {
        showToast('Error', 'Masukkan nama pemilik rekening', 'error');
        return;
    }
    
    if (!amount || amount < 50000) {
        showToast('Error', 'Minimal withdraw Rp50.000', 'error');
        return;
    }
    
    const currentSaldo = parseInt(document.getElementById('availableBalance').dataset.saldo || 0);
    if (amount > currentSaldo) {
        showToast('Error', 'Saldo tidak mencukupi', 'error');
        return;
    }
    
    // Show confirmation modal
    withdrawAmount = amount;
    showConfirmModal({
        method,
        accountNumber,
        bankName,
        accountName,
        amount
    });
};

// Show confirmation modal
const showConfirmModal = (data) => {
    const modal = document.getElementById('confirmModal');
    
    document.getElementById('confirmMethod').textContent = data.method === 'BANK' ? 
        `${data.method} - ${data.bankName}` : data.method;
    document.getElementById('confirmDestination').textContent = data.accountNumber;
    document.getElementById('confirmName').textContent = data.accountName;
    document.getElementById('confirmAmount').textContent = formatCurrency(data.amount);
    
    // Store data for confirmation
    modal.dataset.withdrawData = JSON.stringify(data);
    
    modal.classList.remove('hidden');
};

// Close modal
window.closeModal = () => {
    const modal = document.getElementById('confirmModal');
    modal.classList.add('hidden');
    delete modal.dataset.withdrawData;
};

// Confirm withdraw
window.confirmWithdraw = async () => {
    const modal = document.getElementById('confirmModal');
    const data = JSON.parse(modal.dataset.withdrawData || '{}');
    const confirmBtn = modal.querySelector('.btn-primary');
    
    if (!data.method) return;
    
    setLoading(confirmBtn, true);
    
    try {
        // Create withdraw document
        const withdrawData = {
            uid: currentUser.uid,
            method: data.method,
            accountNumber: data.accountNumber,
            accountName: data.accountName,
            amount: data.amount,
            status: 'PENDING',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
        };
        
        if (data.method === 'BANK') {
            withdrawData.bankName = data.bankName;
        }
        
        // Add to withdraw collection
        await addDoc(collection(db, 'withdraw'), withdrawData);
        
        // Update user saldo (decrement)
        const userRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userRef, {
            saldo: increment(-data.amount),
            totalWithdraw: increment(data.amount)
        });
        
        showToast('Sukses', 'Permintaan withdraw berhasil dibuat!', 'success');
        
        setTimeout(() => {
            window.location.href = 'riwayat.html';
        }, 1500);
        
    } catch (error) {
        console.error('Withdraw error:', error);
        showToast('Error', 'Gagal membuat permintaan withdraw', 'error');
        setLoading(confirmBtn, false);
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', init);
